/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== uartecho.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* Define System States */
enum LED_States {INIT, WAIT1, WAIT2, ON, OFF};

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    char            input; // define serial buffer as 1 byte of RAM
    unsigned char   state; // define state as 1 byte of RAM
    UART_Handle     uart;
    UART_Params     uartParams;

    /* Call driver init functions */
    GPIO_init();
    UART_init();

    /* Configure the LED pin */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Create a UART with data processing off. */
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;

    uart = UART_open(CONFIG_UART_0, &uartParams);

    if (uart == NULL) {
        /* UART_open() failed */
        while (1);
    }


    /* Loop forever echoing */
    while (1) {
        switch (state)  // Transitions
        {
            case INIT:  // From INIT to WAIT1 - Check if input char is 'o'
                if (input == 'o' || input == 'O')
                {
                    state = WAIT1; // Transition to WAIT1 State
                }
                break;
            case WAIT1: // From WAIT1 to ON or WAIT2 - Check if input char is 'n' or 'f'
                if (input == 'n' || input == 'N')
                {
                    state = ON; // Input was 'on' - Transition to ON State
                }
                else if (input == 'f' || input == 'F')
                {
                    state = WAIT2; // Transition to WAIT2 State
                }
                break;
            case WAIT2: // From WAIT2 to OFF - Check if input char is 'f'
                if (input == 'f' || input == 'F')
                {
                    state = OFF; // Input was 'off' - Transition to OFF State
                }
                break;
            default:   // Any other input will set to state to INIT
                state = INIT;
                break;
        }

        switch (state)  // State actions
        {
            case INIT:                                              // INIT State actions
                UART_read(uart, &input, 1);                         // Get first char from input
                UART_write(uart, &input, 1);                        // Display the input
                break;
            case WAIT1:                                             // WAIT1 State actions
                UART_read(uart, &input, 1);                         // Get second char from input
                UART_write(uart, &input, 1);                        // Display the input
                break;
            case WAIT2:                                             // WAIT2 State actions
                UART_read(uart, &input, 1);                         // Get third char from input
                UART_write(uart, &input, 1);                        // Display the input
                break;
            case ON:                                                // ON State actions
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);  // Turn red led on
                break;
            case OFF:                                               // OFF State actions
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF); // Turn red led off
                break;
            default:
                break;
        }
    }
}
